require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD) {
  console.error('Missing SESSION_SECRET or ADMIN_PASSWORD environment variable.');
  process.exit(1);
}

const db = new Database(process.env.DB_PATH || path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`);

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
  scriptSrc: ["'self'"], imgSrc: ["'self'", 'data:'],
  formAction: ["'self'"], frameAncestors: ["'none'"]
}}}));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(session({
  name: 'secureportal.sid',
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: __dirname }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: isProduction, sameSite: 'strict', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false,
  message: 'Too many attempts. Please wait and try again.' });
const adminLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false });

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function requireUser(req, res, next) {
  if (!req.session.userId) return res.redirect('/login.html');
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.isAdmin) return res.redirect('/admin.html');
  next();
}

app.post('/api/register', authLimiter, async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254)
    return res.status(400).send('Enter a valid email address.');
  if (password.length < 8 || password.length > 72)
    return res.status(400).send('Password must be between 8 and 72 characters.');
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)').run(email, hash);
    req.session.userId = result.lastInsertRowid;
    res.redirect('/account.html');
  } catch (err) {
    if (String(err.code).includes('SQLITE_CONSTRAINT')) return res.status(409).send('An account with that email already exists.');
    console.error(err); res.status(500).send('Could not create the account.');
  }
});

app.post('/api/login', authLimiter, async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT id, password_hash FROM users WHERE email = ?').get(email);
  const ok = user ? await bcrypt.compare(password, user.password_hash) : false;
  if (!ok) return res.status(401).send('Email or password is incorrect.');
  req.session.userId = user.id;
  res.redirect('/account.html');
});

app.get('/api/me', requireUser, (req, res) => {
  const user = db.prepare('SELECT email, created_at FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Not signed in' });
  res.json(user);
});

app.post('/api/admin/login', adminLimiter, (req, res) => {
  if (!safeEqual(req.body.password || '', process.env.ADMIN_PASSWORD))
    return res.status(401).send('Incorrect administrator password.');
  req.session.isAdmin = true;
  res.redirect('/admin-dashboard.html');
});

app.get('/api/admin/users', requireAdmin, (req, res) => {
  const users = db.prepare('SELECT id, email, created_at FROM users ORDER BY id DESC').all();
  res.json(users);
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

app.get('/health', (_req, res) => res.json({ status: 'ok' }));
app.listen(PORT, () => console.log(`SecurePortal listening on port ${PORT}`));
